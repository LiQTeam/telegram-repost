"""
تنظیماتِ مرکزیِ دکمه‌های رنگی — همه‌ی دکمه‌ها (زیرِ پستِ مقصد، تبلیغات، و منوهای
ادمین/کاربری) از همین یک فایل کنترل می‌شن. برای تغییرِ رنگ/متن/لینک/زمان‌بندی فقط
همین فایل رو ویرایش کن و ربات رو ری‌استارت کن.

رنگ‌های مجاز (همون رنگ‌های ازپیش‌تعریف‌شده‌ی تلگرام):
    "primary"  → آبیِ تیره
    "danger"   → قرمز
    "success"  → سبز
    None        → پیش‌فرض (بی‌رنگ/شفاف)

نکته: رنگ فقط با اپلیکیشن‌های به‌روزِ تلگرام دیده می‌شه؛ نسخه‌های قدیمی همون دکمه‌ی
پیش‌فرض رو نشون می‌دن. هیچ کتابخانه‌ی جدیدی لازم نیست.
"""
from __future__ import annotations

# رنگ‌های معتبر (برای اعتبارسنجی؛ مقدارِ نامعتبر نادیده گرفته و بی‌رنگ فرض می‌شه)
VALID_COLORS = {"primary", "danger", "success"}


# ============================================================================
# ۱) دکمه‌های زیرِ پست‌های ری‌پست‌شده — به تفکیکِ کانالِ مقصد
# ----------------------------------------------------------------------------
# هر مقصد رو با «آیدیِ عددیِ کانال» (chat_id، مثل -1001234567890) یا با
# «یوزرنیم» (مثل "@myChannel") کلید می‌زنی. برای هر مقصد می‌تونی:
#   - enabled: True/False  → این مقصد اصلاً دکمه بگیره یا نه
#   - time_window: بازه‌ی ساعتی که دکمه‌ها می‌شینن (وقتِ تهران، ۰ تا ۲۴)
#         {"start": 8, "end": 23}  → فقط بینِ ۸ صبح تا ۲۳ دکمه بذار
#         {"start": 22, "end": 6}  → بازه‌ی شبانه (از ۲۲ تا ۶ صبح)
#         None                      → همیشه (۲۴ساعته)
#   - buttons: لیستِ ۱ تا ۴ دکمه؛ هر دکمه {"text", "url", "color"}
#         url = همون کانالی که با زدنِ دکمه کاربر بهش می‌ره.
#
# هر مقصدی که این‌جا تعریف نشه، از DEFAULT_REPOST پیروی می‌کنه.
REPOST_BUTTONS: dict = {
    # نمونه (کامنت رو بردار و ویرایش کن):
    # -1001234567890: {
    #     "enabled": True,
    #     "time_window": {"start": 8, "end": 23},
    #     "buttons": [
    #         {"text": "دریافت کانفیگ رایگان | نامحدود", "url": "https://t.me/vfreepn", "color": "danger"},
    #         {"text": "کانالِ دوم",                      "url": "https://t.me/second",  "color": "primary"},
    #     ],
    # },
    # "@myChannel": {
    #     "enabled": False,   # این مقصد هیچ دکمه‌ای نگیره
    # },
}

# پیش‌فرض برای هر مقصدی که در REPOST_BUTTONS تعریف نشده.
# اگه می‌خوای مقصدهای تعریف‌نشده هیچ دکمه‌ای نگیرن، "enabled" رو False کن.
DEFAULT_REPOST: dict = {
    "enabled": True,
    "time_window": None,   # همیشه
    "buttons": [
        {"text": "دریافت کانفیگ رایگان | نامحدود", "url": "https://t.me/vfreepn", "color": "danger"},
    ],
}

# چند دکمه در هر ردیف چیده بشه (۱ تا ۴).
REPOST_BUTTONS_PER_ROW = 1

# اگه متنِ یک پست شاملِ این نشانه باشه، زیرِ اون پستِ خاص هیچ دکمه‌ای گذاشته نمی‌شه.
# (برای وقتی دستی می‌خوای زیرِ یه پستِ مشخص دکمه نیاد.) خالی بذاری یعنی غیرفعال.
NO_BUTTON_MARKER = "#nobtn"


# ============================================================================
# ۲) رنگِ دکمه‌های بخشِ تبلیغات
# ----------------------------------------------------------------------------
# متن و لینکِ دکمه‌های تبلیغ همون‌جای همیشگی (منوی تبلیغات) تنظیم می‌شن؛ این‌جا فقط
# رنگ اضافه می‌شه. اگه یه دکمه‌ی تبلیغ رنگِ اختصاصیِ ذخیره‌شده نداشته باشه، این رنگ
# روش می‌شینه. None یعنی بی‌رنگ.
ADS_DEFAULT_COLOR = "primary"


# ============================================================================
# ۳) رنگِ دکمه‌های منوی ادمین/کاربری
# ----------------------------------------------------------------------------
# هر دکمه‌ی منو یک callback_data داره (شناسه‌ی داخلیِ دکمه). این‌جا با اون
# callback_data (یا پیشوندش) رنگ رو تعیین می‌کنی. تطبیق: اول تطبیقِ کامل، بعد
# طولانی‌ترین پیشوندِ منطبق. کلیدِ "*" رنگِ پیش‌فرضِ همه‌ی دکمه‌های منوست.
#
# مثال:
#   "*": "primary",         # همه‌ی دکمه‌های منو آبی
#   "del_": "danger",       # هر دکمه‌ای که callback_dataش با del_ شروع شه قرمز
#   "confirm": "success",   # دکمه‌ی دقیقاً confirm سبز
MENU_BUTTON_COLORS: dict = {
    # "*": "primary",
    # "del_": "danger",
    # "confirm_": "success",
}


# ============================================================================
# منطقِ خالص (بدونِ وابستگی به تلگرام) — تست‌پذیر
# ============================================================================
def _norm_color(color):
    """رنگِ نامعتبر یا خالی → None (بی‌رنگ)."""
    return color if color in VALID_COLORS else None


def within_time_window(window, now_hour: int) -> bool:
    """آیا ساعتِ فعلی (۰-۲۳) داخلِ بازه‌ست؟ بازه‌ی شبانه (start>end) هم پشتیبانی می‌شه.
    window=None یا ناقص یا start==end → همیشه True (۲۴ساعته)."""
    if not window:
        return True
    start = window.get("start")
    end = window.get("end")
    if start is None or end is None:
        return True
    try:
        start = int(start) % 24
        end = int(end) % 24
        now_hour = int(now_hour) % 24
    except (TypeError, ValueError):
        return True
    if start == end:
        return True  # بازه‌ی صفر یا کاملِ ۲۴ساعته
    if start < end:
        return start <= now_hour < end
    # بازه‌ی شبانه، مثلاً ۲۲ تا ۶
    return now_hour >= start or now_hour < end


def resolve_repost_config(chat_id) -> dict:
    """کانفیگِ دکمه‌ی مربوط به یک مقصد رو برمی‌گردونه. اول با کلیدهای مختلف (خودِ
    مقدار، رشته، عدد) داخلِ REPOST_BUTTONS می‌گرده؛ اگه نبود DEFAULT_REPOST."""
    for key in _candidate_keys(chat_id):
        if key in REPOST_BUTTONS:
            return REPOST_BUTTONS[key] or {}
    return DEFAULT_REPOST or {}


def _candidate_keys(chat_id):
    """شکل‌های مختلفِ کلیدِ ممکن برای یک chat_id (عدد/رشته/یوزرنیم)."""
    keys = []
    if chat_id is None:
        return keys
    keys.append(chat_id)
    s = str(chat_id)
    keys.append(s)
    # یوزرنیم با/بدون @
    if s.startswith("@"):
        keys.append(s[1:])
    else:
        keys.append("@" + s)
    # عدد
    try:
        keys.append(int(chat_id))
    except (TypeError, ValueError):
        pass
    # حذفِ تکراری‌ها با حفظِ ترتیب
    seen = set()
    out = []
    for k in keys:
        if k not in seen:
            seen.add(k)
            out.append(k)
    return out


def sanitized_repost_buttons(cfg: dict) -> list[dict]:
    """لیستِ دکمه‌های معتبرِ یک کانفیگ رو (حداکثر ۴ تا) با رنگِ نرمال‌شده برمی‌گردونه.
    دکمه‌ی بدونِ text یا url نادیده گرفته می‌شه."""
    raw = (cfg or {}).get("buttons") or []
    out = []
    for b in raw:
        if not isinstance(b, dict):
            continue
        text = (b.get("text") or "").strip()
        url = (b.get("url") or "").strip()
        if not text or not url:
            continue
        out.append({"text": text, "url": url, "color": _norm_color(b.get("color"))})
        if len(out) >= 4:  # سقفِ ۴ دکمه
            break
    return out


def has_no_button_marker(text) -> bool:
    """آیا این متن نشانه‌ی «دکمه نذار» رو داره؟"""
    if not NO_BUTTON_MARKER:
        return False
    return NO_BUTTON_MARKER in (text or "")


def style_for_callback(callback_data) -> str | None:
    """رنگِ یک دکمه‌ی منو رو بر اساسِ callback_dataش پیدا می‌کنه: اول تطبیقِ کامل،
    بعد طولانی‌ترین پیشوندِ منطبق، در نهایت کلیدِ عمومیِ "*"."""
    if not MENU_BUTTON_COLORS:
        return None
    if callback_data:
        if callback_data in MENU_BUTTON_COLORS:
            return _norm_color(MENU_BUTTON_COLORS[callback_data])
        best = None
        for key, color in MENU_BUTTON_COLORS.items():
            if key in ("*", ""):
                continue
            if callback_data.startswith(key) and (best is None or len(key) > len(best)):
                best = key
        if best is not None:
            return _norm_color(MENU_BUTTON_COLORS[best])
    if "*" in MENU_BUTTON_COLORS:
        return _norm_color(MENU_BUTTON_COLORS["*"])
    return None
