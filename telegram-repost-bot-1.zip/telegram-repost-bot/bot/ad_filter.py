"""
تشخیصِ پست‌های تبلیغاتی که لابه‌لای پست‌های عادیِ کانالِ مبدأ قرار می‌گیرن
(کالکشنِ «کانال‌های پیشنهادی»، تبلیغِ فروشگاه/محصول، پروموشنِ سایت‌های شرط‌بندی/
قمار و...) تا فیلتر شن و ری‌پست نشن.

--- موتورِ نسخه ۳ (بافت‌محور + داوریِ AI روی هرپست) ---
نسخه‌ی ۲ کلمات رو در چند «تیر» (قوی/متوسط/ضعیف) دسته‌بندی می‌کرد ولی دو مشکل
داشت که هر دو از گزارش‌های واقعی دیده شدن:

  ۱) «کلیدواژه‌ی سفارشیِ کاربر» (لیستی که خودِ کاربر از منوی فیلترِ تبلیغات
     اضافه می‌کنه) همیشه ردِ قطعی و بدونِ قیدوشرط بود - یعنی اگه کاربر واژه‌ای
     مثلِ «عضو» یا «کمیسیون» رو اضافه کرده باشه (برای گرفتنِ چیزی مثلِ «عضو
     کانال شوید»)، یک خبرِ کاملاً عادی که فقط این کلمه رو به‌عنوانِ بخشی از یک
     جمله داره (مثلِ «عضو تحریریه» یا «رئیس کمیسیونِ امنیتِ ملی») هم اشتباهاً
     تبلیغ تشخیص داده می‌شد - بدونِ این‌که هیچ‌وقت بافتِ جمله خونده بشه.
  ۲) لایه‌ی داوریِ LLM فقط برای مواردِ «مرزیِ» موتورِ قاعده‌محور صدا زده می‌شد؛
     پس پستی که واقعاً تبلیغه ولی هیچ‌کدوم از کلیدواژه‌های تعریف‌شده رو نداره
     (مثلِ تبلیغِ یک سایت/کسب‌وکارِ جدید با ادبیاتی که در لیست نیست) هیچ‌وقت به
     LLM نمی‌رسید و رد نمی‌شد.

نسخه‌ی ۳ هر دو رو این‌طور حل می‌کنه:

  • کلیدواژه‌ی سفارشی دیگه ردِ قطعیِ کور نیست؛ مثلِ یک نشانه‌ی قوی امتیاز می‌گیره
    ولی همیشه پرچمِ «نیازِ به داوریِ بافتی» رو هم بالا می‌بره.
  • اگه کلیدِ سرویسِ هوش مصنوعی (Mistral/Groq) ست شده باشه، دیگه فقط برای
    موارد مرزی صدا زده نمی‌شه: LLM روی *همه‌یِ* پست‌ها (به‌جز پستِ خالص کانفیگ/
    پروکسی که برای سرعت معاف می‌مونه) با خواندنِ کاملِ متن داوریِ نهایی می‌کنه
    و می‌تونه در هر دو جهت نتیجه‌ی موتورِ قاعده‌محور رو برگردونه: هم پستِ عادی‌ای
    که کلیدواژه‌ی مشکوک توش بود رو تبرئه کنه (نه تبلیغ)، هم پستی که هیچ‌کدوم
    از کلیدواژه‌ها رو نداشت ولی واقعاً داره چیزی (سایتِ شرط‌بندی، کسب‌وکار،
    سرویس و...) تبلیغ می‌کنه رو رد کنه. (نگاه کن به llm_classify/classify_async)
  • بدونِ کلیدِ AI یا وقتی کاربر از منو خاموشش کرده («فیلترِ هوشمند»)، همون
    موتورِ قاعده‌محور به‌تنهایی کار می‌کنه (کلیدواژه‌ی سفارشی همچنان امتیازِ
    بالا می‌گیره) تا هیچ پستی به‌خاطرِ نبودِ اینترنت/کلید گیر نکنه.

منشن‌ها و لینک‌ها دیگه *به‌خودیِ‌خود* پست رو تبلیغ نمی‌کنن (طبقِ درخواست: منشن/سایت
باید حذف بشه، نه این‌که باعثِ ردِ پست شه). فقط ساختارِ «پستی که تقریباً کاملاً یک
لیستِ منشن/لینکه + یک واژه‌ی تبلیغاتی» به‌عنوانِ کالکشن شناسایی می‌شه.
"""
from __future__ import annotations

import logging
import re

log = logging.getLogger("repost_bot.ad_filter")

# ---------------------------------------------------------------------------
# کلیدواژه‌های «قابلِ نمایش/ویرایش» برای منوی ربات. این لیست فقط برای سازگاری با
# منوها و تنظیماتِ قدیمی نگه داشته شده و به‌عنوانِ «واژه‌های تبلیغاتیِ عمومی» به
# موتور تزریق می‌شه؛ ولی برخلافِ نسخه‌ی قبل، حالا این‌ها «ضعیف/بافت‌محور»ن و به
# تنهایی پست رو تبلیغ نمی‌کنن مگر این‌که نشانه‌ی دیگه‌ای هم باشه.
DEFAULT_KEYWORDS = [
    "تبلیغ", "تبلیغات", "تبلیغی", "تبلیغ در کانال", "تبلیغ در گروه",
    "تبلیغ بدید", "تبلیغ بدهید", "تبلیغ بزارید", "تبلیغ بذارید",
    "درج تبلیغ", "درج آگهی", "ثبت آگهی",
    "همکاری تبلیغاتی", "همکاری در تبلیغات",
    "اسپانسر",
    "حمایت شده", "حمایت‌شده", "پشتیبانی شده",
    "شماره تماس تبلیغات", "شماره برای تبلیغات", "تماس برای تبلیغ",
    "کانال پیشنهادی", "کانال های پیشنهادی", "کانال‌های پیشنهادی",
    "پیشنهاد کانال",
    "ثبت سفارش", "ثبت سفارش تبلیغات", "سفارش دهید", "سفارش بدید",
    "خرید از ما", "خرید کنید", "همین الان بخر", "همین حالا بخر",
    "تخفیف ویژه", "تخفیف شگفت‌انگیز", "کد تخفیف",
    "قیمت ویژه", "فروش ویژه", "پیشنهاد ویژه", "پیشنهاد شگفت‌انگیز",
    "لینک عضویت", "لینک جوین", "لینک ثبت نام", "لینک ثبت‌نام",
    "جوین شوید", "عضو کانال شوید", "عضو شوید",
    "عضویت در کانال", "عضویت در گروه",
    "کد دعوت", "کد معرف", "کد معرفی",
    "واریز ریالی", "برداشت ریالی", "واریز و برداشت",
    "کارت به کارت", "بازگشت باخت", "بازگشت ضرر",
    "بونوس", "پاداش ثبت نام",
    "شرط بندی", "شرط‌بندی", "قمار", "کازینو", "کازینو آنلاین",
    "پیش بینی ورزشی", "پیش‌بینی ورزشی",
    "سایت بین المللی", "سایت معتبر", "سایت خارجی",
    "فیلترشکن", "VPN", "وی‌پی‌ان", "پروکسی", "پروکسی تلگرام",
    "sponsored", "advertisement", "promo code", "discount code", "coupon code",
    "buy now", "limited offer", "hot offer", "flash sale", "special offer",
    "join now", "subscribe now", "click here", "click link",
    "link in bio", "bio link", "ad", "promo", "promotion",
]

# پسوندهای فایلی که به‌طورِ پیش‌فرض مسدود می‌شن (اپ‌های آندروید/ویندوز/iOS که
# لابه‌لای پست‌های عادی برای تبلیغِ سایت‌های شرط‌بندی/قمار و... پخش می‌شن).
DEFAULT_BLOCKED_EXTENSIONS = ["apk", "exe", "msi", "bat", "scr", "ipa", "jar"]


def default_extensions_text() -> str:
    return ", ".join(DEFAULT_BLOCKED_EXTENSIONS)


def parse_extensions(raw: str) -> list[str]:
    out = []
    for e in (raw or "").split(","):
        e = e.strip().lower().lstrip(".")
        if e:
            out.append(e)
    return out


def default_keywords_text() -> str:
    return ", ".join(DEFAULT_KEYWORDS)


def parse_keywords(raw: str) -> list[str]:
    return [k.strip() for k in (raw or "").split(",") if k.strip()]


# ===========================================================================
#  نرمال‌سازیِ متن
# ===========================================================================
_ZWNJ = "\u200c"
_AR_YE = "\u064a"      # ي عربی
_AR_KE = "\u0643"      # ك عربی
_AR_ALEF_MAKSURA = "\u0649"

def _normalize(text: str) -> str:
    """یکسان‌سازیِ حروفِ عربی/فارسی، حذفِ نیم‌فاصله، فشرده‌سازیِ فاصله‌ها و
    lowercase کردنِ لاتین. باعث می‌شه تطبیقِ عبارت‌ها به شکلِ نوشتنِ کاربر
    (با/بدون نیم‌فاصله، ي/ی عربی و...) حساس نباشه."""
    if not text:
        return ""
    t = text.replace(_ZWNJ, " ")
    # نویسه‌های نامرئی/جهت‌دهی و کشیدگیِ عربی (ـــ) رو حذف کن. اگه اینا وسطِ متن
    # باشن (که در پست‌های تلگرامی زیاد پیش میاد)، کلیدواژه دیگه تطبیق نمی‌خوره -
    # مثلاً «فیلـترشکن» یا کلمه‌ای که RLM لای حروفش افتاده.
    t = re.sub(r"[\u0640\u200b\u200d\u200e\u200f\u202a-\u202e\u2060\u2066-\u2069\ufeff]", "", t)
    t = t.replace(_AR_YE, "ی").replace(_AR_ALEF_MAKSURA, "ی").replace(_AR_KE, "ک")
    t = t.lower()
    t = re.sub(r"\s+", " ", t)
    return t


# ===========================================================================
#  کانفیگ / پروکسی (معافیت)
# ===========================================================================
_MENTION_RE = re.compile(r"@([A-Za-z0-9_]{4,})")
_URL_RE = re.compile(r"(?:https?://\S+|www\.\S+|(?:t\.me|telegram\.me)/\S+)", re.I)

_CONFIG_RE = re.compile(
    r"(?:vless|vmess|trojan|ss|ssr|hysteria2?|hy2|tuic|juicity|wireguard|socks5?|naive|snell|"
    r"clash|sing-box|warp)://"
    r"|tg://proxy"
    r"|(?:https?://)?t(?:elegram)?\.me/proxy\?"
    r"|(?:https?://)?t(?:elegram)?\.me/socks\?"
    r"|security=reality"
    r"|type=(?:tcp|ws|grpc|http)&",
    re.I,
)


def text_has_config(text: str) -> bool:
    return bool(_CONFIG_RE.search(text or ""))


def post_has_config(post) -> bool:
    for attr in ("raw_text", "html_text"):
        val = getattr(post, attr, "") or ""
        if _CONFIG_RE.search(val):
            return True
    for m in getattr(post, "media", None) or []:
        name = getattr(m, "filename", "") or ""
        if name and _CONFIG_RE.search(name):
            return True
    return False


# ===========================================================================
#  فایل‌های مسدود (APK و...)
# ===========================================================================
def blocked_file(media: list, extensions: list[str]) -> tuple[bool, str]:
    exts = {e.strip().lower().lstrip(".") for e in extensions if e and e.strip()}
    if not exts:
        return False, ""
    for m in media or []:
        if getattr(m, "type", "") != "document":
            continue
        name = (getattr(m, "filename", "") or getattr(m, "url", "") or "").strip()
        if not name:
            continue
        name_lower = name.lower()
        suffix_ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
        if suffix_ext in exts:
            return True, name
        tokens = set(re.findall(r"[a-z0-9]+", name_lower))
        if exts & tokens:
            return True, name
    return False, ""


# ===========================================================================
#  تیرهای نشانه (بافت‌محور)
# ===========================================================================
# نکته: همه‌ی عبارت‌ها به‌شکلِ نرمال‌شده (بدون نیم‌فاصله، ی/ک فارسی، lowercase)
# نوشته شدن تا با _normalize هم‌خوان باشن.

# ---- (۱) نشانه‌های قوی: به‌تنهایی تبلیغ محسوب می‌شن (تقریباً بدونِ خطای مثبت) ----
STRONG_SIGNALS = [
    # سفارشِ تبلیغ / تعرفه
    "درج تبلیغ", "درج اگهی", "ثبت اگهی", "ثبت سفارش تبلیغ", "سفارش تبلیغ",
    "رزرو تبلیغ", "پذیرش تبلیغ", "تبلیغ پذیرفته", "پکیج تبلیغات", "پکیج تبلیغاتی",
    "تعرفه تبلیغ", "ریت تبلیغ", "جهت تبلیغ", "برای تبلیغ در", "بابت تبلیغ",
    "تبلیغ در کانال", "تبلیغ در گروه", "همکاری تبلیغاتی", "همکاری در تبلیغات",
    "تبلیغ بذارید", "تبلیغ بزارید", "تبلیغ بدید", "تبلیغ بدهید",
    "شماره تماس تبلیغات", "شماره برای تبلیغات", "تماس برای تبلیغ",
    "ادمین تبلیغات", "ایدی تبلیغات",
    # کالکشنِ کانال‌ها
    "کانال پیشنهادی", "کانال های پیشنهادی", "کانالهای پیشنهادی", "پیشنهاد کانال",
    "کانال های زیر رو جوین", "کانالهای زیر رو جوین",
    # شرط‌بندی/قمار (عبارت‌های تقریباً همیشه‌تبلیغاتی)
    "کازینو انلاین", "سایت شرط بندی", "سایت شرطبندی", "بازگشت باخت", "بازگشت ضرر",
    "معتبرترین سایت", "معتبر ترین سایت", "بهترین سایت شرط",
    # انگلیسی
    "sponsored", "advertisement", "promo code", "discount code", "coupon code",
    "link in bio", "bio link",
]

# ---- (۲) واژه‌های شرط‌بندی/قمار (متوسط - دوتا با هم، یا یکی + فراخوان/ثبت‌نام) ----
GAMBLING_SIGNALS = [
    "شرط بندی", "شرطبندی", "کازینو", "قمار", "پیش بینی ورزشی", "پیشبینی ورزشی",
    "بونوس", "پاداش ثبت نام", "واریز و برداشت", "واریز ریالی", "برداشت ریالی",
    "کارت به کارت", "سایت معتبر", "سایت بین المللی", "سایت خارجی",
    "بازی انفجار", "انفجار", "تخته نرد انلاین", "پوکر", "رولت",
    "بت", "شرط ببند", "ضریب", "جایزه نقدی",
]

# ---- (۳) فراخوانِ اقدام / نیتِ تجاری (متوسط) ----
CTA_SIGNALS = [
    "همین الان بخر", "همین حالا بخر", "همین الان ثبت نام", "همین حالا ثبت نام",
    "خرید کنید", "بخرید", "خرید از ما", "ثبت سفارش", "سفارش دهید", "سفارش بدید",
    "عضو شوید", "عضو کانال شوید", "عضو کانال شو", "جوین شوید", "جوین کنید",
    "جوین کن", "به کانال بپیوندید", "به گروه بپیوندید", "عضویت در کانال",
    "عضویت در گروه", "ثبت نام کنید", "ثبت نام کن", "همین حالا عضو",
    "کلیک کنید", "کلیک کن", "لینک ثبت نام", "لینک عضویت", "لینک جوین",
    "کد دعوت", "کد معرف", "کد معرفی", "ترفند ثبت نام", "اموزش ثبت نام",
    "buy now", "join now", "subscribe now", "click here", "click link",
]

# ---- (۴) تخفیف/پروموشنِ تجاری (متوسط) ----
PROMO_SIGNALS = [
    "تخفیف ویژه", "تخفیف شگفت انگیز", "کد تخفیف", "قیمت ویژه", "فروش ویژه",
    "پیشنهاد ویژه", "پیشنهاد شگفت انگیز", "حراج", "فقط امروز", "تعداد محدود",
    "فرصت محدود", "limited offer", "hot offer", "flash sale", "special offer",
]

# ---- (۵) واژه‌های ضعیف/دوپهلو: هیچ‌وقت به‌تنهایی؛ فقط با نشانه‌ی دیگه ----
WEAK_SIGNALS = [
    "vpn", "وی پی ان", "پروکسی", "فیلترشکن", "پروکسی تلگرام",
    "اسپانسر", "حمایت شده", "پشتیبانی شده", "کمیسیون", "سایت", "لینک",
    "تخفیف", "قیمت", "تبلیغ", "تبلیغات", "تبلیغی", "ad", "promo", "promotion",
]

# واژه‌های «تبلیغی» که وقتی کنارِ یک راهِ تماس (منشن/شماره) بیان، یعنی طرف داره
# سفارشِ تبلیغ/فروش می‌گیره (نشانه‌ی «تماس برای سفارش»).
_ORDER_WORDS = ["تبلیغ", "تبلیغات", "سفارش", "رزرو", "تعرفه", "خرید", "فروش"]


def _find(signal_list: list[str], norm_text: str) -> list[str]:
    """عبارت‌هایی از لیست که در متنِ نرمال‌شده اومدن رو برمی‌گردونه.
    برای واژه‌های کوتاهِ لاتین (ad/bt/ss...) از مرزِ کلمه استفاده می‌شه تا
    زیرمجموعه‌ی کلمه‌ی دیگه‌ای نباشن."""
    out = []
    for s in signal_list:
        sn = _normalize(s)
        if not sn:
            continue
        if sn.isascii() and len(sn) <= 3:
            if re.search(r"\b" + re.escape(sn) + r"\b", norm_text):
                out.append(s)
        elif sn == "بت":  # «بت» فارسیِ کوتاه هم مرزِ کلمه لازم داره
            if re.search(r"(?<![\u0600-\u06FF])بت(?![\u0600-\u06FF])", norm_text):
                out.append(s)
        else:
            if sn in norm_text:
                out.append(s)
    return out


def _visible_prose_len(text: str) -> int:
    """طولِ متنِ «واقعی» بعد از حذفِ منشن‌ها، لینک‌ها و فاصله‌ها - برای تشخیصِ
    پستی که تقریباً کاملاً یک لیستِ لینک/منشنه."""
    t = _URL_RE.sub(" ", text or "")
    t = _MENTION_RE.sub(" ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return len(t)


# ===========================================================================
#  موتورِ قاعده‌محور
# ===========================================================================
def analyze(
    text: str,
    self_username: str,
    keywords: list[str],
    min_mentions: int = 3,
    min_links: int = 2,
    score_threshold: int = 4,
    config_source: str | None = None,
) -> tuple[bool, str, dict]:
    """
    خروجی: (تبلیغ‌است؟, دلیلِ فارسی, جزئیات).
    امضا با نسخه‌ی قبل سازگاره؛ ولی حالا:
      • score = «اطمینان» بین ۰ تا ۱۰۰.
      • threshold = آستانه‌ی مؤثر (از score_threshold مشتق می‌شه؛ عددِ کوچک‌تر
        در تنظیمات = حساس‌تر).
      • detail["borderline"] = True یعنی نتیجه مرزیه و ارزشِ داوریِ LLM داره.
    منشن/لینک به‌خودیِ‌خود امتیاز نمی‌دن (طبقِ درخواست، اون‌ها حذف می‌شن نه این‌که
    پست رو رد کنن)؛ فقط ساختارِ «کالکشنِ لینک/منشن + واژه‌ی تبلیغاتی» می‌شماره.

    config_source: نسخه‌ی HTMLِ پست (post.html_text)، اختیاری. وقتی لینکِ
    کانفیگ/پروکسیِ منبع به‌شکلِ متنِ لینک‌شده بوده (مثلاً «آواکادوپروکسی» یا
    «پروکسی ۱» به‌جای خودِ آدرس)، آدرسِ واقعی (vless://، t.me/proxy? و...) فقط
    توی href می‌مونه و از get_text() ساقط می‌شه؛ پس تشخیصِ کانفیگ باید href رو
    هم ببینه، وگرنه این‌جور پست‌ها (که خودشون کانفیگ‌ان) اشتباهی وارد مسیرِ
    امتیازدهی/AI می‌شن و ممکنه AD تشخیص داده بشن.
    """
    text = text or ""
    norm = _normalize(text)
    detail: dict = {
        "score": 0, "threshold": 0, "keywords": [],
        "mentions": len(_MENTION_RE.findall(text)),
        "links": len(_URL_RE.findall(text)),
        "borderline": False, "config": False,
    }

    # آستانه‌ی مؤثر: پیش‌فرضِ score_threshold=4 → cutoff=55. هر واحد کم‌تر ~۱۰ واحد
    # حساس‌تر. محدوده‌ی امن: ۲۵ تا ۹۰.
    cutoff = max(25, min(90, 55 + (4 - int(score_threshold or 4)) * 10))
    detail["threshold"] = cutoff

    # کلیدواژه‌های سفارشیِ کاربر (از منوی «فیلترِ تبلیغات»).
    default_norm = {_normalize(k) for k in DEFAULT_KEYWORDS}
    custom_kw = [k for k in (keywords or []) if _normalize(k) not in default_norm]
    custom_hits = list(dict.fromkeys(_find(custom_kw, norm))) if custom_kw else []

    # ---- معافیتِ کانفیگ/پروکسی ----
    # فقط وقتی معاف می‌شه که هیچ کلیدواژه‌ی سفارشی‌ای هم تطبیق نخورده باشه؛
    # وگرنه پستِ تبلیغاتی‌ای که یک لینکِ پروکسی هم چسبونده رو صرفاً به‌خاطرِ
    # همون لینک از فیلتر رد می‌کرد (باگِ «آواکادوپروکسی»). اگه کلیدواژه‌ی
    # سفارشی باشه، مسیرِ عادیِ امتیازدهی + داوریِ بافتی/AI طیّ می‌شه.
    has_config = bool(_CONFIG_RE.search(text)) or bool(
        config_source and _CONFIG_RE.search(config_source)
    )
    if has_config and not custom_hits:
        detail["config"] = True
        detail["threshold"] = 100
        return False, "پستِ حاویِ کانفیگ/پروکسی است؛ از فیلترِ تبلیغات معاف شد", detail

    strong = _find(STRONG_SIGNALS, norm)
    gambling = list(dict.fromkeys(_find(GAMBLING_SIGNALS, norm)))
    cta = list(dict.fromkeys(_find(CTA_SIGNALS, norm)))
    promo = list(dict.fromkeys(_find(PROMO_SIGNALS, norm)))
    weak = list(dict.fromkeys(_find(WEAK_SIGNALS, norm)))

    # «تماس برای سفارش/تبلیغ»: راهِ تماس (منشن یا شماره) + واژه‌ی سفارش/تبلیغ.
    has_contact = bool(_MENTION_RE.search(text)) or bool(re.search(r"\b0?9\d{9}\b", norm))
    order_word = any(_normalize(w) in norm for w in _ORDER_WORDS)
    contact_for_order = has_contact and order_word

    # کالکشنِ لینک/منشن: پستی که تقریباً کاملاً لیستِ منشن/لینکه.
    n_ment = len(_MENTION_RE.findall(text))
    n_link = len(_URL_RE.findall(text))
    prose = _visible_prose_len(text)
    link_heavy = (n_ment + n_link) >= max(3, int(min_mentions or 3)) and prose < 40

    confidence = 0
    reasons: list[str] = []

    # (۱) نشانه‌ی قوی → کافیه.
    if strong:
        confidence += 75 + 10 * (len(strong) - 1)
        reasons.append("نشانه‌ی قویِ تبلیغاتی: " + "، ".join(strong[:4]))

    # (۲) خوشه‌ی شرط‌بندی/قمار.
    if len(gambling) >= 2:
        confidence += 70
        reasons.append("چند واژه‌ی شرط‌بندی/قمار: " + "، ".join(gambling[:4]))
    elif len(gambling) == 1 and (cta or promo or contact_for_order):
        confidence += 60
        reasons.append("واژه‌ی شرط‌بندی همراهِ فراخوان/ثبت‌نام: " + gambling[0])
    elif len(gambling) == 1:
        confidence += 25  # مرزی: شاید فقط موضوعِ خبر باشه

    # (۳) فراخوانِ اقدام (خرید/ثبت‌نام/عضویت).
    if len(cta) >= 2:
        confidence += 65
        reasons.append("چند فراخوانِ اقدام: " + "، ".join(cta[:4]))
    elif len(cta) == 1 and (promo or contact_for_order or link_heavy):
        confidence += 60
        reasons.append("فراخوانِ اقدام همراهِ نشانه‌ی تجاری: " + cta[0])
    elif len(cta) == 1:
        confidence += 30

    # (۴) تخفیف/پروموشن.
    if len(promo) >= 2:
        confidence += 60
        reasons.append("چند نشانه‌ی تخفیف/پروموشن: " + "، ".join(promo[:4]))
    elif len(promo) == 1 and (cta or contact_for_order):
        confidence += 55
    elif len(promo) == 1:
        confidence += 25

    # (۵) تماس برای سفارش/تبلیغ.
    if contact_for_order:
        confidence += 40
        reasons.append("راهِ تماس همراهِ واژه‌ی سفارش/تبلیغ")

    # (۶) کالکشنِ لینک/منشن + واژه‌ی تبلیغاتی.
    if link_heavy and (weak or cta or promo or gambling or custom_hits):
        confidence += 45
        reasons.append("پست عمدتاً لیستِ منشن/لینک است (شبیهِ کالکشنِ تبلیغاتی)")

    # (۷) کلیدواژه‌های سفارشیِ کاربر - مثلِ یک نشانه‌ی قوی امتیاز می‌گیره (کاربر
    # صریحاً این کلمه رو مشکوک اعلام کرده)، ولی برخلافِ نسخه‌ی قبل، دیگه به‌تنهایی
    # و کورکورانه ردِ قطعی نیست: چون این کلمه‌ها اغلب دوپهلو هستن (مثلِ «عضو»،
    # «کمیسیون») و ممکنه در یک خبرِ کاملاً عادی هم بیان، همیشه پرچمِ «مرزی» رو
    # بالا می‌بریم تا اگه AI در دسترس باشه، با خواندنِ کاملِ متن تصمیمِ نهایی رو
    # بگیره (نگاه کن به classify_async). بدونِ AI، همین امتیازِ بالا باعثِ ردشدن
    # می‌شه - دقیقاً رفتارِ قدیم، فقط این‌بار قابلِ اصلاح‌شدن توسطِ AI.
    if custom_hits:
        confidence += 78 + 8 * (len(custom_hits) - 1)
        reasons.append("کلیدواژه‌ی سفارشیِ شما در متن پیدا شد: " + "، ".join(custom_hits[:4]))
        detail["borderline"] = True

    # (۸) واژه‌های ضعیف - فقط وقتی نشانه‌ی غیرِضعیف هم هست (بافت‌گیری).
    if weak and confidence > 0:
        confidence += min(24, 8 * len(weak))
        reasons.append("واژه‌های مرتبط: " + "، ".join(weak[:4]))

    confidence = min(100, confidence)
    detail["score"] = confidence
    detail["keywords"] = (strong + gambling + cta + promo + custom_hits)[:8]

    is_ad = confidence >= cutoff

    # منطقه‌ی مرزی: بینِ (cutoff-20) و (cutoff+5) که موتور خیلی مطمئن نیست →
    # ارزشِ داوریِ انسان‌گونه‌ی LLM (اگه در دسترس باشه) رو داره.
    if (cutoff - 20) <= confidence <= (cutoff + 5):
        detail["borderline"] = True

    if not reasons:
        reason_text = "هیچ نشانه‌ی تبلیغاتیِ روشنی پیدا نشد"
    else:
        reason_text = "؛ ".join(reasons)
    return is_ad, reason_text, detail


# ===========================================================================
#  حذفِ منشن‌ها و سایت‌ها از متنِ پست (طبقِ درخواست: حذف کن، نه این‌که رد کنی)
# ===========================================================================
# لینک‌های پروکسی/کانفیگ نباید حذف بشن (خودشون محتوان). این regexها فقط
# منشن‌ها و URLهای «معمولی» رو هدف می‌گیرن.
_A_TAG_RE = re.compile(r"<a\b[^>]*>(.*?)</a>", re.I | re.S)
_HREF_RE = re.compile(r'href\s*=\s*["\']([^"\']+)["\']', re.I)


def _is_config_or_proxy(s: str) -> bool:
    if not s:
        return False
    if _CONFIG_RE.search(s):
        return True
    low = s.lower()
    # امضای اختصاصیِ VFREEPN (formatter.VFREEPN_SIGNATURE_HTML) هیچ‌وقت نباید
    # به‌عنوانِ لینک/منشنِ معمولی حذف بشه - طبقِ درخواستِ کاربر.
    if "vfreepn" in low:
        return True
    return "proxy" in low


def strip_entities_html(
    html_text: str, *, strip_mentions: bool = True, strip_links: bool = True
) -> str:
    """منشن‌ها (@user) و لینک‌های معمولی (http/https/www/t.me) رو از HTMLِ پست
    حذف می‌کنه و بقیه‌ی متن رو دست‌نخورده نگه می‌داره. لینک/کدِ کانفیگ و پروکسی
    هیچ‌وقت حذف نمی‌شن (چون خودِ محتوان). این تابع برای زمانی‌ست که کاربر خواسته
    «اگه منشن/سایت داشت حذف شه، نه این‌که پست رد شه»."""
    if not html_text:
        return html_text

    txt = html_text

    # کانفیگ/پروکسیِ خام در متن ممکنه خودش شاملِ @ (مثلِ vless://uuid@host:443) یا
    # چیزی شبیهِ URL باشه؛ قبل از هر کاری این توکن‌ها رو پنهان می‌کنیم تا نه
    # منشن‌گیر و نه لینک‌گیر بهشون دست نزنه، و آخرِ کار برشون می‌گردونیم.
    _protected: list[str] = []

    def _mask(m: "re.Match") -> str:
        _protected.append(m.group(0))
        return f"\x00CFG{len(_protected) - 1}\x00"

    _config_token_re = re.compile(
        r"(?:vless|vmess|trojan|ss|ssr|hysteria2?|hy2|tuic|juicity|wireguard|"
        r"socks5?|naive|snell|clash|sing-box|warp)://\S+"
        r"|tg://(?:proxy|socks)\S*"
        r"|(?:https?://)?t(?:elegram)?\.me/(?:proxy|socks)\?\S+",
        re.I,
    )
    txt = _config_token_re.sub(_mask, txt)
    _masked_before = txt  # مبنای مقایسه‌ی خط‌به‌خط (با کانفیگ‌های ماسک‌شده)

    if strip_links:
        # تگ‌های <a href=...> که به یک لینکِ معمولی اشاره می‌کنن: کلاً حذف
        # (هم متنِ نمایشی هم خودِ لینک). کانفیگ/پروکسی معاف.
        def _a_repl(m: "re.Match") -> str:
            whole = m.group(0)
            href_m = _HREF_RE.search(whole)
            href = href_m.group(1) if href_m else ""
            inner = m.group(1) or ""
            if _is_config_or_proxy(href) or _is_config_or_proxy(inner):
                return whole
            if href and _URL_RE.search(href):
                return ""
            return whole
        txt = _A_TAG_RE.sub(_a_repl, txt)

        # URLهای خام در متن (خارج از تگ).
        txt = _URL_RE.sub(lambda m: m.group(0) if _is_config_or_proxy(m.group(0)) else "", txt)

    if strip_mentions:
        txt = _MENTION_RE.sub("", txt)

    # هر خطی که به‌خاطرِ حذفِ منشن/لینک عوض شده رو *کامل* بردار (نه فقط منشن/لینک)،
    # تا جمله‌ی نصفه و بی‌معنی به‌جا نمونه. خطی که کانفیگِ ماسک‌شده داره استثناست و
    # حفظ می‌شه (خودِ محتوان). خط‌هایی که اصلاً عوض نشدن دست‌نخورده می‌مونن.
    if txt != _masked_before:
        orig_lines = _masked_before.split("\n")
        new_lines = txt.split("\n")
        if len(orig_lines) == len(new_lines):
            txt = "\n".join(
                nl for ol, nl in zip(orig_lines, new_lines)
                if not (nl != ol and "\x00CFG" not in ol)
            )

    # برگرداندنِ کانفیگ‌های پنهان‌شده.
    for i, original in enumerate(_protected):
        txt = txt.replace(f"\x00CFG{i}\x00", original)

    # جمع‌وجور کردنِ فقط فاصله‌ی آخرِ خط و خطِ خالیِ اضافه. فاصله‌های داخلی
    # (ستون‌بندیِ متن) عمداً حفظ می‌شن تا چیدمان/استایلِ اصلیِ پست به‌هم نریزه.
    txt = re.sub(r" *\n", "\n", txt)
    txt = re.sub(r"\n{3,}", "\n\n", txt)
    return txt.strip("\n")


# ===========================================================================
#  لایه‌ی داوریِ انسان‌گونه با LLM (روی همه‌ی پست‌ها - نه فقط مواردِ مرزی)
# ===========================================================================
# نکته: این پرامپت با چند مثالِ متضاد (few-shot) نوشته شده چون مدلِ پیش‌فرض
# (llama-3.1-8b-instant از طریقِ Groq) مدلِ کوچیکیه؛ مثال‌های صریح دقتش رو
# روی همین نوع اشتباه (کلمه‌ی دوپهلو در خبرِ عادی) بالا می‌بره.
_LLM_SYSTEM = (
    "تو یک ناظرِ باتجربه‌ی محتوای تلگرامی هستی. کارت اینه که با خواندنِ کاملِ "
    "کپشنِ یک پست (نه فقط دنبالِ چند کلمه گشتن)، تشخیص بدی این پست واقعاً "
    "«تبلیغ» است یا یک محتوای عادی (خبر، تحلیل، نقل‌قول، مطلبِ اجتماعی/سیاسی/"
    "ورزشی و...).\n\n"
    "پست «تبلیغ» است اگر متن دارد یکی از این‌ها را می‌فروشد/ترویج/تشویق می‌کند:\n"
    "- سایت یا اپلیکیشنِ شرط‌بندی، قمار، پیش‌بینیِ ورزشی، کازینو\n"
    "- فروشگاه، محصول، خدمات، یا هر کسب‌وکارِ دیگر (حتی اگر اسمِ خاصی نبرده باشد)\n"
    "- دعوت به عضویت/ثبت‌نام/جوین‌شدن در یک کانال، گروه، ربات یا سرویس\n"
    "- کد تخفیف/معرف، پکیج/تعرفه‌ی تبلیغات، یا سفارشِ درجِ تبلیغ در کانال\n"
    "- لیستِ «کانال‌های پیشنهادی» یا کالکشنی از لینک/آیدی برای جوین‌شدن\n"
    "این‌ها را حتی وقتی متن از هیچ کلمه‌ی «مشکوکِ» شناخته‌شده‌ای استفاده نکرده هم "
    "باید تشخیص بدهی - معیار، *نیتِ واقعیِ متن* است (آیا دارد چیزی را به خواننده "
    "می‌فروشد یا دعوت به کاری تجاری می‌کند)، نه وجودِ یک کلمه‌ی خاص.\n\n"
    "پست «عادی/SAFE» است اگر صرفاً خبر می‌دهد، تحلیل/نظر می‌دهد، نقل‌قول می‌کند، یا "
    "رویدادی را توصیف می‌کند - حتی اگر تصادفاً کلمه‌ای مثلِ «عضو» (عضوِ یک نهاد/"
    "تحریریه)، «کمیسیون» (کمیسیونِ مجلس)، «تبلیغات» (به‌عنوانِ موضوعِ خبر، نه دعوت)، "
    "«VPN»، «قیمت» یا «سایت» را در دلِ یک جمله‌ی خبری/توصیفی داشته باشد. وجودِ این "
    "کلمه‌ها به‌تنهایی هرگز به‌معنیِ تبلیغ‌بودن نیست؛ باید کلِ جمله را خواند.\n\n"
    "چند نمونه‌ی تضادی:\n"
    "۱) «کامبیز توانا، عضو تحریریه ایراناینترنشنال، درباره حملات حوثی‌ها گفت...» "
    "→ SAFE (خبر است؛ «عضو» یعنی عضوِ هیئتِ تحریریه، نه دعوت به عضویت).\n"
    "۲) «رئیس کمیسیون امنیت ملی مجلس در واکنش به توافق بریتانیا نوشت...» "
    "→ SAFE (خبرِ سیاسی است؛ «کمیسیون» نامِ یک نهاد است).\n"
    "۳) «عضو کانال ما شوید و از تخفیف ویژه بهره‌مند شوید، لینک در بیو» "
    "→ AD (دعوتِ صریح به عضویت + تخفیف).\n"
    "۴) «بهترین پلتفرم برای معامله و سرمایه‌گذاری، همین امروز ثبت‌نام کن و جایزه بگیر» "
    "→ AD (تبلیغِ یک سرویس/کسب‌وکار است؛ حتی بدونِ کلمه‌ی «شرط‌بندی» یا «کازینو»).\n\n"
    "فقط و دقیقاً یکی از این دو کلمه را بنویس: AD یا SAFE. هیچ توضیحِ اضافه‌ای نده."
)


def _llm_snippet(text: str, head: int = 1100, tail: int = 500) -> str:
    """برای پست‌های کوتاه، کلِ متن. برای پست‌های طولانی، *هم ابتدا هم انتهای* متن رو
    می‌فرسته (نه فقط ۱۵۰۰ کاراکترِ اول). دلیل: یک الگوی خیلی رایج در تبلیغاتِ
    پنهان اینه که یک خبر/متنِ کاملاً عادی بالای پست میاد و جمله‌ی تبلیغاتی (لینکِ
    عضویت، کد تخفیف، دعوتِ خرید و...) ته‌ی پست چسبونده می‌شه؛ اگه فقط از اول برش
    بخوریم، دقیقاً همون بخشِ تبلیغاتی که باید تشخیص داده بشه از دیدِ مدل حذف می‌شه."""
    if len(text) <= head + tail:
        return text
    return text[:head] + "\n...\n" + text[-tail:]


async def llm_classify(text: str, hint_keywords: list[str] | None = None) -> bool | None:
    """با LLM (Mistral/Groq از طریقِ AIRouter) تشخیص می‌ده پست تبلیغه یا نه، با
    خواندنِ کاملِ متن (نه فقط تطبیقِ کلمه). True=تبلیغ، False=عادی، None=در
    دسترس نبود/خطا (که یعنی باید به نتیجه‌ی موتورِ قاعده‌محور تکیه کرد).
    hint_keywords: کلیدواژه‌هایی که موتورِ قاعده‌محور توی متن پیدا کرده - فقط
    به‌عنوانِ سرنخ به مدل داده می‌شه، نه حکمِ قطعی؛ خودِ مدل با خواندنِ کلِ متن
    تصمیم می‌گیره (ممکنه با این سرنخ‌ها مخالفت کنه). هیچ‌وقت استثنا پرتاب نمی‌کنه."""
    text = (text or "").strip()
    if not text:
        return None
    try:
        from .config import MISTRAL_API_KEY, GROQ_API_KEY
        if not (MISTRAL_API_KEY or GROQ_API_KEY):
            return None
        from .ai_router import AIRouter
        router = AIRouter()
        try:
            snippet = _llm_snippet(text)
            hint_line = (
                f"کلیدواژه‌هایی که یک فیلترِ ساده در این متن پیدا کرده (ممکنه کاملاً "
                f"بی‌ربط و تصادفی باشن - خودت با خواندنِ کاملِ متن تصمیم بگیر، لازم "
                f"نیست باهاش موافق باشی): {'، '.join(hint_keywords[:6])}\n\n"
                if hint_keywords else ""
            )
            out = await router.route(
                f"{hint_line}متنِ پست:\n---\n{snippet}\n---\nآیا این پست واقعاً تبلیغ "
                f"است؟ فقط AD یا SAFE.",
                task_type="general", system_prompt=_LLM_SYSTEM, temperature=0.0,
            )
        finally:
            try:
                await router.close()
            except Exception:  # noqa: BLE001
                pass
        if not out:
            return None
        up = out.strip().upper()
        if "AD" in up and "SAFE" not in up:
            return True
        if "SAFE" in up:
            return False
        return None
    except Exception as e:  # noqa: BLE001
        log.debug("داوریِ LLMِ تبلیغ ناموفق بود (به موتورِ قاعده‌محور تکیه می‌شود): %s", e)
        return None


async def classify_async(
    text: str,
    self_username: str,
    keywords: list[str],
    *,
    min_mentions: int = 3,
    min_links: int = 2,
    score_threshold: int = 4,
    use_llm: bool = True,
    config_source: str | None = None,
) -> tuple[bool, str, dict]:
    """تشخیصِ نهایی: اول موتورِ قاعده‌محور (برای سرعت و برای معافیتِ کانفیگ/
    پروکسی). بعد، اگه use_llm=True و کلیدِ AI در دسترس باشه، LLM روی خودِ متنِ
    کامل (نه فقط موارد مرزی) داوریِ نهایی می‌کنه و حرفِ آخر رو می‌زنه - چه نتیجه‌ی
    موتورِ قاعده‌محور را تایید کنه، چه رد کنه (در هر دو جهت: هم پستِ عادیِ دارایِ
    کلیدواژه‌ی دوپهلو رو تبرئه می‌کنه، هم پستِ تبلیغاتیِ بدونِ کلیدواژه رو رد
    می‌کنه). اگه AI نبود/خطا داد، همون نتیجه‌ی قاعده‌محور برمی‌گرده (هیچ پستی
    به‌خاطرِ نبودِ AI گم یا معطل نمی‌مونه).

    config_source: نگاه کن به docstringِ analyze() - نسخه‌ی HTMLِ پست، برای
    دیدنِ لینکِ کانفیگ/پروکسیِ پنهان‌شده پشتِ متنِ لینک (مثلِ «آواکادوپروکسی»)."""
    is_ad, reason, detail = analyze(
        text, self_username, keywords,
        min_mentions=min_mentions, min_links=min_links, score_threshold=score_threshold,
        config_source=config_source,
    )
    if detail.get("config"):
        # پستِ کانفیگ/پروکسیِ خالص - از قبل معاف شده، نیازی به AI نیست.
        return is_ad, reason, detail
    if use_llm:
        verdict = await llm_classify(text, hint_keywords=detail.get("keywords"))
        if verdict is not None:
            detail["llm"] = "AD" if verdict else "SAFE"
            detail["rule_engine_verdict"] = is_ad
            if verdict != is_ad:
                reason = (reason + "؛ " if reason else "") + (
                    "داوریِ هوشِ مصنوعی (با خواندنِ کاملِ متن، نتیجه‌ی موتورِ قاعده‌محور "
                    "را اصلاح کرد): " + ("تبلیغ" if verdict else "عادی")
                )
            else:
                reason = (reason + "؛ " if reason else "") + (
                    "داوریِ هوشِ مصنوعی: تبلیغ" if verdict else "داوریِ هوشِ مصنوعی: عادی"
                )
            return verdict, reason, detail
    return is_ad, reason, detail
