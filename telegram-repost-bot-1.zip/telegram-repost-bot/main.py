#!/usr/bin/env python3
"""
نقطه‌ی ورود ربات ری‌پست هوشمند MR LiQ.
اجرا: python3 main.py
"""
from __future__ import annotations

import sys

from telegram import BotCommand, MenuButtonCommands, Update
from telegram.ext import Application, ContextTypes
from telegram.request import HTTPXRequest

from bot import config
from bot.handlers import register_handlers
from bot.scheduler import schedule_jobs


async def _global_error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    هندلرِ سراسریِ خطا. بدونِ این، هر exceptionِ کنترل‌نشده‌ی داخلِ هندلرها
    (مثلاً fail شدنِ ارسالِ پیامِ خصوصی به کاربری که هنوز /start نزده) فقط
    توی لاگ می‌افتاد و از دیدِ کاربر هیچ اتفاقی نمی‌افتاد - نه خطا، نه نتیجه.
    حالا حداقل لاگ می‌شه و در صورتِ امکان به خودِ کاربر هم خبر داده می‌شه.
    """
    import logging
    logging.getLogger(__name__).exception("خطای کنترل‌نشده در پردازشِ آپدیت: %s", context.error)

    try:
        if isinstance(update, Update) and update.effective_chat:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text="⚠️ یه خطای غیرمنتظره پیش اومد. دوباره امتحان کن یا لاگ رو چک کن.",
            )
    except Exception:
        pass


_COMMANDS = [
    BotCommand("start", "شروع / نمایش منوی اصلی"),
    BotCommand("menu", "نمایش دوبارهٔ منوی اصلی"),
    BotCommand("stats", "آمار ربات"),
    BotCommand("sources", "کانال‌های مبدأ"),
    BotCommand("extsources", "منابع اکستنشن (گروه‌های خصوصی)"),
    BotCommand("destinations", "کانال‌های مقصد"),
    BotCommand("watermark", "واترمارک تصویر"),
    BotCommand("footer", "امضای پایان پست"),
    BotCommand("format", "قالب‌بندی متن"),
    BotCommand("adfilter", "فیلتر پست‌های تبلیغاتی"),
    BotCommand("help", "راهنما"),
]


async def _post_init(application: Application) -> None:
    """
    فعال‌سازیِ دکمه‌ی Menu (آیکونِ سه‌خط) کنارِ نوارِ متن برای دسترسیِ سریع به
    دستورات، به‌جای نوعِ پیش‌فرض/بدونِ آیکون.

    همچنین سرویس‌های پس‌زمینه (مانیتورینگ منابع سرور، بکاپ خودکار روزانه،
    تبلیغات، ارسالِ دستیِ زمان‌بندی‌شده، سرورِ API اکستنشن) زمان‌بندی می‌شن تا
    حلقه‌ی اصلیِ ربات را قفل نکنن - نگاه کن به توضیحِ _start_background_tasks
    برای این‌که چرا مستقیم این‌جا create_task نمی‌شن.
    """
    from bot.resource_monitor import ResourceMonitor
    from bot.backup_manager import BackupManager

    await application.bot.set_my_commands(_COMMANDS)
    await application.bot.set_chat_menu_button(menu_button=MenuButtonCommands())

    resource_monitor = ResourceMonitor(application.bot)
    backup_manager = BackupManager(application.bot)
    application.bot_data["resource_monitor"] = resource_monitor
    application.bot_data["backup_manager"] = backup_manager

    # ⚠️ باگِ مهم: قبلاً همین‌جا (تویِ post_init) مستقیماً application.create_task(...)
    # برای این تسک‌ها صدا زده می‌شد. طبقِ خودِ python-telegram-bot، post_init دقیقاً
    # همون لحظه‌ای اجرا می‌شه که application هنوز واقعاً «running» نیست (این حالت
    # چند خط بعدتر، توسطِ run_polling، ست می‌شه) - برای همین create_task هر بار با
    # PTBUserWarning («won't be automatically awaited») هشدار می‌داد و این تسک‌ها
    # اصلاً توسطِ خودِ PTB ردیابی نمی‌شدن. نتیجه: سرِ هر ری‌استارت/توقفِ سرویس، این
    # تسک‌ها به‌جای cancel/awaitِ تمیزِ PTB، وسطِ کار (pending) نابود می‌شدن و یه
    # مشتی «asyncio - ERROR - Task was destroyed but it is pending!» توی لاگ
    # می‌ریخت. راهِ حل: زمان‌بندیِ ساختِ این تسک‌ها با یک jobِ یک‌بارِ JobQueue
    # (when=0) که تضمین می‌کنه فقط *بعدِ* این‌که application واقعاً start شد اجرا
    # بشه - اون‌جا create_task دیگه هم بدونِ هشدار کار می‌کنه هم توسطِ PTB برای
    # shutdownِ تمیز ردیابی می‌شه.
    application.job_queue.run_once(_start_background_tasks, when=0)


async def _start_background_tasks(context: ContextTypes.DEFAULT_TYPE) -> None:
    """ساختِ واقعیِ تسک‌های پس‌زمینه - نگاه کن به توضیحِ باگ توی _post_init."""
    application = context.application
    resource_monitor = application.bot_data["resource_monitor"]
    backup_manager = application.bot_data["backup_manager"]
    application.create_task(resource_monitor.run_loop())
    application.create_task(backup_manager.run_daily_backup())

    # ماژولِ ایزوله‌ی «تبلیغات» — دیتابیس/حلقه‌ی خودش را در یک تسکِ
    # asyncio جدا راه‌اندازی می‌کند؛ هیچ تاثیری روی حلقه‌ی اصلیِ ری‌پست ندارد.
    from bot import auto_poster as _auto_poster
    _auto_poster.setup(application)

    # ماژولِ ایزوله‌ی «ارسالِ دستی + زمان‌بندی» — حلقه‌ی چکِ پست‌های زمان‌بندی‌شده
    # در یک تسکِ asyncio جدا (مستقل از حلقه‌ی اصلیِ ری‌پست و از حلقه‌ی تبلیغات).
    from bot.manual_poster import run_manual_scheduler_loop as _manual_scheduler_loop
    application.create_task(_manual_scheduler_loop(application.bot))

    # API اکستنشنِ مرورگر (گروه‌های خصوصیِ تلگرام‌وب) - تسکِ جداگانه، فقط اگه
    # توی .env فعال شده باشه (EXTENSION_API_ENABLED=true)، وگرنه بی‌اثره.
    from bot.extension_api import run_ext_api_server as _run_ext_api_server
    application.create_task(_run_ext_api_server(application.bot))


async def _post_shutdown(application: Application) -> None:
    """
    موقعِ خاموش‌شدنِ ربات (Ctrl+C یا systemctl stop) صدا زده می‌شه. ماژولِ
    auto_poster (تبلیغات) دیگه منبعِ خارجیِ خاصی برای تمیزکاری نداره؛ این
    فراخوانی فقط برای سازگاری با نقطه‌ی اتصالِ قبلی نگه داشته شده.
    """
    from bot import auto_poster as _auto_poster
    try:
        await _auto_poster.shutdown()
    except Exception:
        pass


def main() -> None:
    log = config.setup_logging()

    errors = config.validate()
    if errors:
        for e in errors:
            log.error(e)
        log.error("فایل .env رو کامل کن (از .env.example کپی بگیر) و دوباره اجرا کن.")
        sys.exit(1)

    # concurrent_updates=True: چند تا آپدیت (پیام/کلیکِ دکمه) می‌تونن هم‌زمان
    # پردازش بشن، نه یکی‌یکی توی صف. این دقیقاً همون چیزیه که باعث می‌شه ربات
    # موقعی که یک پردازشِ سنگین (مثلا واترمارک/AI روی یک عکس) در حال اجراست،
    # هنوز به کلیک‌های دیگه (مثلا باز کردنِ لیستِ کانال‌های مبدأ) فوراً جواب بده -
    # رفعِ همون باگِ «باید چند بار کلیک کنم تا جواب بده».
    # تنظیماتِ پیش‌فرضِ python-telegram-bot برای تایم‌اوتِ آپلود/دانلود (چندین
    # ثانیه) برای ویدیوهای حجیم اصلاً کافی نیست و باعثِ شکستِ ارسال با خطای
    # «Timed out» می‌شد - حتی وقتی خودِ فایل کاملاً دانلود شده بود. اینجا
    # تایم‌اوت‌ها رو به‌طورِ قابل‌توجهی زیاد می‌کنیم (به‌خصوص media_write_timeout
    # که مخصوصِ آپلودِ فایل/عکس/ویدیوعه) تا حتی ویدیوهای سنگین هم فرصتِ کافی
    # برای رسیدن به تلگرام داشته باشن.
    request = HTTPXRequest(
        connect_timeout=30.0,
        read_timeout=90.0,
        write_timeout=90.0,
        pool_timeout=60.0,
        media_write_timeout=300.0,
    )

    application = (
        Application.builder()
        .token(config.BOT_TOKEN)
        .request(request)
        .concurrent_updates(config.MAX_CONCURRENT_HEAVY_JOBS + 5)
        .post_init(_post_init)
        .post_shutdown(_post_shutdown)
        .build()
    )

    register_handlers(application)
    application.add_error_handler(_global_error_handler)
    schedule_jobs(application)

    log.info(
        "ربات با موفقیت بالا اومد و در حال گوش‌دادن به پیام‌هاست... "
        "(پردازش هم‌زمانِ آپدیت‌ها فعاله)"
    )
    # "channel_post" هم اضافه شد: بدونش، وقتی ادمین بعد از زدنِ «ویرایش کپشن/
    # تغییر عکس/تغییر ویدیو» مستقیماً توی کانالِ تایید (نه توی چتِ خصوصی) عکس/
    # متن/ویدیویِ جدید رو پست می‌کرد، ربات اصلاً اون آپدیت رو دریافت نمی‌کرد.
    application.run_polling(allowed_updates=["message", "callback_query", "channel_post"], drop_pending_updates=True)


if __name__ == "__main__":
    main()