#!/usr/bin/env bash
# ============================================================
#  نصب کاملاً خودکارِ ربات ری‌پست هوشمند MR LiQ
#  اجرا: sudo bash install.sh
#  هیچ سوالی پرسیده نمی‌شه؛ همه‌چیز از قبل تنظیم شده.
# ============================================================
set -euo pipefail

C_RESET="\033[0m"
C_GREEN="\033[1;32m"
C_RED="\033[1;31m"
C_CYAN="\033[1;36m"
C_YEL="\033[1;33m"
C_MAG="\033[1;35m"

info()  { echo -e "${C_CYAN}[i]${C_RESET} $1"; }
ok()    { echo -e "${C_GREEN}[✓]${C_RESET} $1"; }
warn()  { echo -e "${C_YEL}[!]${C_RESET} $1"; }
err()   { echo -e "${C_RED}[x]${C_RESET} $1"; }
title() { echo -e "${C_MAG}$1${C_RESET}"; }

if [[ $EUID -ne 0 ]]; then
   err "این اسکریپت باید با دسترسی root/sudo اجرا بشه. مثال: sudo bash install.sh"
   exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ============================================================
#  مقادیر ثابت (از پیش تنظیم‌شده)
# ============================================================
BOT_TOKEN="8625716049:AAF_AAq-9QteutE6XpWdm9LjpjmANmvUbzI"
ADMIN_IDS="8017393582"
DEFAULT_DEST_ID="-1004354822676"
TZ_VALUE="Asia/Tehran"
SERVICE_NAME="mrliq-bot"
PANEL_CMD="mrliq"

MISTRAL_API_KEY="sIW6TNY6p1LIwo4vvEcfuyGCewZkRQ8e"
GROQ_API_KEY="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"

# کاربران پیش‌فرض (اسم|آیدی عددی کانال/گروه تایید اختصاصی|آیدی عددی تلگرام کاربر)
DEFAULT_USERS=(
  "مهدی|-1004372616638|220878410"
  "داریوش|-1003924798008|1936247822"
  "پارسا|-1004429287189|"
)


DEFAULT_SOURCE_CHANNELS=(
  gizmiztel
  ufccenter
  hollywoodi_a
  rapiar
  digiato
  havades_fouri
)

# ============================================================
#  هدر
# ============================================================
clear
title "============================================================"
title "   نصب‌کننده‌ی کاملاً خودکارِ ربات ری‌پست هوشمند MR LiQ"
title "============================================================"
echo ""

# ============================================================
#  پیش‌نیازهای سیستمی
# ============================================================
info "در حال بررسی و نصب پیش‌نیازهای سیستمی..."

if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y >/dev/null
    apt-get install -y \
        python3 \
        python3-venv \
        python3-pip \
        curl \
        wget \
        git \
        fonts-dejavu-core \
        build-essential \
        >/dev/null
    ok "پکیج‌های سیستمی (apt) نصب شدند."
elif command -v yum >/dev/null 2>&1; then
    yum install -y \
        python3 \
        python3-pip \
        curl \
        wget \
        git \
        >/dev/null
    ok "پکیج‌های سیستمی (yum) نصب شدند."
elif command -v dnf >/dev/null 2>&1; then
    dnf install -y \
        python3 \
        python3-pip \
        curl \
        wget \
        git \
        >/dev/null
    ok "پکیج‌های سیستمی (dnf) نصب شدند."
else
    warn "پکیج‌منیجر سیستم شناسایی نشد؛ فرض می‌کنیم پیش‌نیازها از قبل نصب‌اند."
fi

if ! command -v python3 >/dev/null 2>&1; then
    err "python3 پیدا نشد. اول اونو نصب کن و دوباره اجرا کن."
    exit 1
fi

if ! command -v pip3 >/dev/null 2>&1; then
    warn "pip3 پیدا نشد، در حال نصب..."
    python3 -m ensurepip --upgrade >/dev/null || true
fi

PY_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
ok "پایتون نسخه $PY_VERSION نصب است."
ok "پیش‌نیازهای سیستمی آماده‌ست."

# ============================================================
#  حذف محیط مجازی قبلی و ساخت جدید
# ============================================================
info "ساخت محیط مجازی پایتون (venv)..."

rm -rf venv
python3 -m venv venv

if [ ! -f "venv/bin/activate" ]; then
    err "ساخت venv ناموفق بود."
    exit 1
fi

source venv/bin/activate

# ارتقای pip
pip install --upgrade pip -q
ok "محیط مجازی ساخته شد."

# ============================================================
#  نصب کتابخانه‌های پایتون از requirements.txt
# ============================================================
info "در حال نصب کتابخانه‌های پایتون (این مرحله ۲-۵ دقیقه طول می‌کشد)..."

if [ ! -f "requirements.txt" ]; then
    err "فایل requirements.txt پیدا نشد."
    exit 1
fi

# نصب با --extra-index-url برای torch
pip install -r requirements.txt --extra-index-url https://download.pytorch.org/whl/cpu -q

if [ $? -ne 0 ]; then
    warn "نصب با --extra-index-url ناموفق بود، تلاش مجدد بدون آن..."
    pip install -r requirements.txt -q
fi

ok "همه کتابخانه‌های پایتون نصب شدند."

# ============================================================
#  ایجاد پوشه‌های مورد نیاز
# ============================================================
info "ایجاد پوشه‌های پروژه..."

mkdir -p models data fonts
mkdir -p data/watermark_templates
mkdir -p logs

ok "پوشه‌های پروژه ایجاد شدند."

# ============================================================
#  دانلود مدل بهبود کیفیت تصویر (Real-ESRGAN)
# ============================================================
# ============================================================
#  دانلود مدل بهبود کیفیت تصویر (Real-ESRGAN)
# ============================================================
SR_MODEL_FILE="models/realesr-general-x4v3.pth"
SR_MODEL_URL="https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-x4v3.pth"
SR_DL_LOG="/tmp/sr_model_download.log"

if [[ -f "$SR_MODEL_FILE" ]]; then
    ok "مدل بهبود کیفیت از قبل موجود است (${SR_MODEL_FILE})"
else
    info "در حال دانلود مدل بهبود کیفیت تصویر (~۴.۷ مگابایت)..."
    rm -f "$SR_DL_LOG"
    if curl -fL --retry 3 --retry-delay 2 --connect-timeout 30 -o "$SR_MODEL_FILE" "$SR_MODEL_URL" >"$SR_DL_LOG" 2>&1 || \
       wget -q --tries=3 --timeout=30 -O "$SR_MODEL_FILE" "$SR_MODEL_URL" >>"$SR_DL_LOG" 2>&1; then
        ACTUAL_SIZE=$(stat -c%s "$SR_MODEL_FILE" 2>/dev/null || echo 0)
        # آستانه‌ی واقعی: خود مدل حدود ۴.۷ مگابایت است؛ هر چیزی زیر ۱ مگابایت
        # قطعاً صفحه‌ی خطا/HTML است، نه فایل مدل واقعی.
        if [ -f "$SR_MODEL_FILE" ] && [ "$ACTUAL_SIZE" -gt 1000000 ]; then
            ok "مدل بهبود کیفیت دانلود شد (حجم: $(du -h "$SR_MODEL_FILE" | cut -f1))"
        else
            rm -f "$SR_MODEL_FILE"
            warn "فایل دانلودشده ناقص است (حجم: ${ACTUAL_SIZE} بایت)، حذف شد. جزئیات خطا: $(tail -3 "$SR_DL_LOG" 2>/dev/null)"
        fi
    else
        rm -f "$SR_MODEL_FILE"
        warn "دانلود مدل بهبود کیفیت شکست خورد (ربات بدون آن هم کار می‌کند). جزئیات خطا: $(tail -3 "$SR_DL_LOG" 2>/dev/null)"
    fi
fi

# ============================================================
#  دانلود مدل LaMa (حذف واترمارک با کیفیت بالا)
# ============================================================
LAMA_MODEL_FILE="models/big-lama.pt"
LAMA_MODEL_URL="https://github.com/Sanster/models/releases/download/add_big_lama/big-lama.pt"
LAMA_MODEL_MD5="e3aa4aaa15225a33ec84f9f4bc47e500"

if [[ -f "$LAMA_MODEL_FILE" ]]; then
    ok "مدل LaMa از قبل موجود است (${LAMA_MODEL_FILE})"
else
    info "در حال دانلود مدل LaMa (~۲۰۰ مگابایت، ممکن است ۵-۱۰ دقیقه طول بکشد)..."
    if curl -fL --retry 3 --retry-delay 5 --connect-timeout 60 -o "$LAMA_MODEL_FILE" "$LAMA_MODEL_URL" 2>/dev/null || \
       wget -q --tries=3 --timeout=60 -O "$LAMA_MODEL_FILE" "$LAMA_MODEL_URL" 2>/dev/null; then
        if [ -f "$LAMA_MODEL_FILE" ] && [ $(stat -c%s "$LAMA_MODEL_FILE" 2>/dev/null || echo 0) -gt 100000000 ]; then
            ok "مدل LaMa دانلود شد (حجم: $(du -h "$LAMA_MODEL_FILE" | cut -f1))"
        else
            rm -f "$LAMA_MODEL_FILE"
            warn "فایل دانلودشده ناقص است، حذف شد."
        fi
    else
        rm -f "$LAMA_MODEL_FILE"
        warn "دانلود مدل LaMa شکست خورد (ربات بدون آن هم کار می‌کند)."
    fi
fi

# ============================================================
#  نصب فونت فارسی (Vazirmatn)
# ============================================================
info "بررسی فونت فارسی..."

if [ ! -f "fonts/Vazirmatn-Bold.ttf" ]; then
    info "دانلود فونت Vazirmatn..."
    curl -fL -o fonts/Vazirmatn-Bold.ttf \
        "https://github.com/rastikerdar/vazirmatn/releases/download/v33.003/Vazirmatn-Bold.ttf" 2>/dev/null || \
    wget -q -O fonts/Vazirmatn-Bold.ttf \
        "https://github.com/rastikerdar/vazirmatn/releases/download/v33.003/Vazirmatn-Bold.ttf" 2>/dev/null || true
fi

if [ -f "fonts/Vazirmatn-Bold.ttf" ]; then
    ok "فونت Vazirmatn نصب است."
else
    warn "فونت Vazirmatn دانلود نشد (واترمارک فارسی ممکن است درست نمایش داده نشود)."
fi

# ============================================================
#  ساخت فایل .env
# ============================================================
info "ساخت فایل .env با مقادیر از پیش تنظیم‌شده..."

cat > .env <<EOF
# ============================================================
#  تنظیمات اصلی ربات
# ============================================================
BOT_TOKEN=${BOT_TOKEN}
ADMIN_IDS=${ADMIN_IDS}
TARGET_CHAT_ID=${DEFAULT_DEST_ID}

# ============================================================
#  تنظیمات دیتابیس و زمان
# ============================================================
DB_PATH=data/bot.sqlite
TIMEZONE=${TZ_VALUE}

# ============================================================
#  تنظیمات همزمانی و کش
# ============================================================
MAX_CONCURRENT_HEAVY_JOBS=3
DOWNLOAD_CACHE_MAX_ITEMS=200
DOWNLOAD_CACHE_TTL_SECONDS=1800

# ============================================================
#  API Keys هوش مصنوعی (Mistral و Groq)
# ============================================================
MISTRAL_API_KEY=${MISTRAL_API_KEY}
GROQ_API_KEY=${GROQ_API_KEY}

# ============================================================
#  تنظیمات تشخیص واترمارک
# ============================================================
TEMPLATE_MATCH_THRESHOLD=0.75
MAX_WATERMARK_AREA_RATIO=0.3
EOF

ok "فایل .env ساخته شد."

# ============================================================
#  آماده‌سازی دیتابیس (کانال مقصد پیش‌فرض + کانال‌های مبدأ)
# ============================================================
info "آماده‌سازی دیتابیس..."

# بررسی وجود cli.py
if [ ! -f "cli.py" ]; then
    warn "فایل cli.py پیدا نشد، دیتابیس به‌صورت دستی تنظیم نمی‌شود."
else
    # افزودن کانال مقصد پیش‌فرض
    python3 cli.py add-destination "${DEFAULT_DEST_ID}" "مقصد پیش‌فرض" 2>/dev/null || true
    ok "کانال مقصد پیش‌فرض (${DEFAULT_DEST_ID}) اضافه شد."

    # افزودن کانال‌های مبدأ
    for CH in "${DEFAULT_SOURCE_CHANNELS[@]}"; do
        info "  افزودن کانال مبدأ @${CH}..."
        python3 cli.py add-source "${CH}" "" --instant "--link=${DEFAULT_DEST_ID}" 2>/dev/null || true
    done

    ok "${#DEFAULT_SOURCE_CHANNELS[@]} کانال مبدأ اولیه اضافه شدند."

    # افزودن کاربران پیش‌فرض (هرکدام با کانال تایید و آیدی تلگرام اختصاصی خودشان)
    for U in "${DEFAULT_USERS[@]}"; do
        U_NAME="${U%%|*}"
        U_REST="${U#*|}"
        U_APPROVAL="${U_REST%%|*}"
        U_TID="${U_REST##*|}"
        info "  افزودن کاربر ${U_NAME} (کانال تایید: ${U_APPROVAL}, تلگرام: ${U_TID:-ندارد})..."
        python3 cli.py add-user "${U_NAME}" "${U_APPROVAL}" "${U_TID}" 2>/dev/null || true
    done
    ok "${#DEFAULT_USERS[@]} کاربر پیش‌فرض اضافه شدند."
fi


# ============================================================
#  نصب سرویس systemd
# ============================================================
if command -v systemctl >/dev/null 2>&1; then
    info "نصب سرویس systemd..."

    SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}.service"

    cat > "$SERVICE_PATH" <<EOF
[Unit]
Description=MR LiQ Telegram Repost Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${SCRIPT_DIR}
ExecStart=${SCRIPT_DIR}/venv/bin/python3 ${SCRIPT_DIR}/main.py
Restart=on-failure
RestartSec=10
User=${SUDO_USER:-root}
Group=${SUDO_USER:-root}
Environment=PYTHONUNBUFFERED=1
EnvironmentFile=${SCRIPT_DIR}/.env
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${SERVICE_NAME}

[Install]
WantedBy=multi-user.target
EOF

    # بارگذاری مجدد systemd
    systemctl daemon-reload

    # فعال‌سازی سرویس (روشن شدن خودکار در boot)
    systemctl enable "${SERVICE_NAME}" >/dev/null 2>&1 || true

    # راه‌اندازی سرویس
    systemctl restart "${SERVICE_NAME}"

    sleep 3

    if systemctl is-active --quiet "${SERVICE_NAME}" 2>/dev/null; then
        ok "ربات با موفقیت به‌عنوان سرویس '${SERVICE_NAME}' اجرا شد."
        ok "سرویس با ری‌بوت سرور خودکار روشن می‌شود."
    else
        err "سرویس بالا نیامد. خطاها را با دستور زیر ببین:"
        echo "   journalctl -u ${SERVICE_NAME} -n 50 --no-pager"
        echo ""
        warn "می‌توانید ربات را به‌صورت دستی اجرا کنید:"
        echo "   cd ${SCRIPT_DIR} && source venv/bin/activate && python3 main.py"
    fi
else
    warn "systemctl پیدا نشد (احتمالاً محیط کانتینر یا سیستم بدون systemd)."
    warn "ربات را به‌صورت دستی با دستور زیر اجرا کنید:"
    echo "   cd ${SCRIPT_DIR} && source venv/bin/activate && python3 main.py"
fi

# ============================================================
#  ساخت پنل مدیریت (دستور سراسری)
# ============================================================
info "ساخت پنل مدیریت سرور (دستور: ${PANEL_CMD})..."

PANEL_PATH="/usr/local/bin/${PANEL_CMD}"

cat > "$PANEL_PATH" <<PANEL_HEADER
#!/usr/bin/env bash
INSTALL_DIR="${SCRIPT_DIR}"
SERVICE_NAME="${SERVICE_NAME}"
PANEL_CMD="${PANEL_CMD}"
PANEL_HEADER

cat >> "$PANEL_PATH" <<'PANEL_BODY'
set -uo pipefail

ENV_FILE="$INSTALL_DIR/.env"
PY="$INSTALL_DIR/venv/bin/python3"
CLI="$INSTALL_DIR/cli.py"

C_RESET="\033[0m"
C_G="\033[1;32m"
C_R="\033[1;31m"
C_C="\033[1;36m"
C_Y="\033[1;33m"
C_M="\033[1;35m"
LRM=$'\u200e'

need_root() {
  if [[ $EUID -ne 0 ]]; then
    echo -e "${C_R}این عملیات نیاز به sudo داره. با: sudo ${PANEL_CMD}${C_RESET}"
    return 1
  fi
  return 0
}

pause() { read -rp $'\n⏎ برای بازگشت به منو Enter رو بزن...' _; }

status_line() {
  if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    echo -e "${C_G}● روشن${C_RESET}"
  else
    echo -e "${C_R}● خاموش${C_RESET}"
  fi
}

restart_bot() {
  systemctl restart "$SERVICE_NAME" 2>/dev/null && echo -e "${C_G}✓ ری‌استارت شد.${C_RESET}" || echo -e "${C_R}✗ خطا در ری‌استارت${C_RESET}"
}

header() {
  clear
  echo -e "${LRM}${C_C}════════════════════════════════════${C_RESET}"
  echo -e "${LRM}${C_M}پنل مدیریت ربات ری‌پست MR LiQ${C_RESET}"
  echo -e "${LRM}وضعیت سرویس (${SERVICE_NAME}): $(status_line)"
  echo -e "${LRM}${C_C}════════════════════════════════════${C_RESET}"
}

show_menu() {
  header
  echo -e "${LRM}  ${C_G}1)${C_RESET} ▶️  روشن‌کردن ربات"
  echo -e "${LRM}  ${C_G}2)${C_RESET} 🔁  ری‌استارت ربات"
  echo -e "${LRM}  ${C_G}3)${C_RESET} ⏹  توقف موقت ربات"
  echo -e "${LRM}  ${C_G}4)${C_RESET} 📴  غیرفعال‌سازی کامل (با ری‌بوت روشن نمی‌شه)"
  echo -e "${LRM}  ${C_G}5)${C_RESET} ✅  فعال‌سازی دوباره و روشن‌کردن"
  echo -e "${LRM}  ${C_G}6)${C_RESET} 📊  وضعیت کامل سرویس"
  echo -e "${LRM}  ${C_G}7)${C_RESET} 📜  لاگ زنده (خروج: Ctrl+C)"
  echo -e "${LRM}  ${C_G}8)${C_RESET} 🔑  تغییر توکن ربات"
  echo -e "${LRM}  ${C_G}9)${C_RESET} 👤  افزودن ادمین جدید"
  echo -e "${LRM}  ${C_G}10)${C_RESET} 🎯  افزودن کانال مقصد"
  echo -e "${LRM}  ${C_G}11)${C_RESET} 📡  افزودن کانال مبدأ"
  echo -e "${LRM}  ${C_G}12)${C_RESET} 🌍  نمایش تنظیمات فعلی (.env)"
  echo -e "${LRM}  ${C_G}13)${C_RESET} 🗑  حذف کامل ربات (غیرقابل بازگشت)"
  echo -e "${LRM}  ${C_G}0)${C_RESET} 🚪  خروج"
  echo
  read -rp "$(echo -e "${LRM}  شماره را وارد کن: ")" CH
  handle "$CH"
}

handle() {
  case "$1" in
    1) need_root && systemctl start "$SERVICE_NAME" 2>/dev/null && echo -e "${C_G}✓ روشن شد.${C_RESET}" || echo -e "${C_R}✗ خطا${C_RESET}"; pause ;;
    2) need_root && restart_bot; pause ;;
    3) need_root && systemctl stop "$SERVICE_NAME" 2>/dev/null && echo -e "${C_Y}⏹ متوقف شد.${C_RESET}" || echo -e "${C_R}✗ خطا${C_RESET}"; pause ;;
    4) need_root && systemctl disable --now "$SERVICE_NAME" 2>/dev/null && echo -e "${C_Y}📴 غیرفعال شد.${C_RESET}" || echo -e "${C_R}✗ خطا${C_RESET}"; pause ;;
    5) need_root && systemctl enable --now "$SERVICE_NAME" 2>/dev/null && echo -e "${C_G}✓ فعال شد.${C_RESET}" || echo -e "${C_R}✗ خطا${C_RESET}"; pause ;;
    6) systemctl status "$SERVICE_NAME" --no-pager -l 2>/dev/null || echo "سرویس یافت نشد."; pause ;;
    7) echo -e "${C_C}لاگ زنده... (خروج: Ctrl+C)${C_RESET}"; journalctl -u "$SERVICE_NAME" -f -n 50 2>/dev/null || echo "خطا در نمایش لاگ"; pause ;;
    8)
      read -rp "🔑 توکن جدید رو بفرست: " NEWTOKEN
      if [[ -n "${NEWTOKEN// }" ]] && need_root; then
        if [ -f "$ENV_FILE" ]; then
          sed -i "s|^BOT_TOKEN=.*|BOT_TOKEN=${NEWTOKEN}|" "$ENV_FILE"
          restart_bot
          echo -e "${C_G}✓ توکن بروزرسانی و ربات ری‌استارت شد.${C_RESET}"
        else
          echo -e "${C_R}فایل .env پیدا نشد.${C_RESET}"
        fi
      fi
      pause ;;
    9)
      read -rp "👤 آیدی عددی ادمین جدید: " NEWADMIN
      if [[ "$NEWADMIN" =~ ^-?[0-9]+$ ]] && need_root; then
        if [ -f "$ENV_FILE" ]; then
          CURRENT=$(grep '^ADMIN_IDS=' "$ENV_FILE" | cut -d'=' -f2-)
          if [[ ",${CURRENT}," == *",${NEWADMIN},"* ]]; then
            echo -e "${C_Y}این آیدی از قبل ادمین بود.${C_RESET}"
          else
            NEW_LIST="${CURRENT:+$CURRENT,}${NEWADMIN}"
            sed -i "s|^ADMIN_IDS=.*|ADMIN_IDS=${NEW_LIST}|" "$ENV_FILE"
            restart_bot
            echo -e "${C_G}✓ اضافه شد و ربات ری‌استارت شد.${C_RESET}"
          fi
        else
          echo -e "${C_R}فایل .env پیدا نشد.${C_RESET}"
        fi
      else
        echo -e "${C_R}آیدی نامعتبر است (فقط عدد).${C_RESET}"
      fi
      pause ;;
    10)
      read -rp "🎯 آیدی عددی کانال مقصد: " DEST_ID
      read -rp "📝 اسم دلخواه (اختیاری): " DEST_TITLE
      if [ -f "$CLI" ] && [ -f "$PY" ]; then
        "$PY" "$CLI" add-destination "$DEST_ID" "$DEST_TITLE"
      else
        echo -e "${C_R}فایل cli.py یا پایتون پیدا نشد.${C_RESET}"
      fi
      pause ;;
    11)
      read -rp "📡 یوزرنیم کانال مبدأ (بدون @): " SRC_USER
      read -rp "📝 اسم دلخواه (اختیاری): " SRC_TITLE
      read -rp "⚡️ حالت ارسال لحظه‌ای باشه؟ [y/N]: " INSTANT
      ARGS=(add-source "$SRC_USER" "$SRC_TITLE")
      if [[ "${INSTANT,,}" == "y" ]]; then ARGS+=(--instant); fi
      if [ -f "$CLI" ] && [ -f "$PY" ]; then
        "$PY" "$CLI" "${ARGS[@]}"
      else
        echo -e "${C_R}فایل cli.py یا پایتون پیدا نشد.${C_RESET}"
      fi
      pause ;;
    12)
      echo
      if [ -f "$ENV_FILE" ]; then
        cat "$ENV_FILE"
      else
        echo -e "${C_R}فایل .env پیدا نشد.${C_RESET}"
      fi
      pause ;;
    13)
      echo -e "${C_R}⚠️  این کار سرویس، فایل‌ها و دیتابیس را کاملاً و برای همیشه پاک می‌کند.${C_RESET}"
      read -rp "برای تایید، دقیقاً بنویس DELETE : " CONFIRM
      if [[ "$CONFIRM" == "DELETE" ]] && need_root; then
        systemctl disable --now "$SERVICE_NAME" 2>/dev/null || true
        rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
        systemctl daemon-reload 2>/dev/null || true
        rm -f "/usr/local/bin/${PANEL_CMD}"
        rm -rf "$INSTALL_DIR"
        echo -e "${C_G}✓ ربات کاملاً از روی سرور حذف شد.${C_RESET}"
        exit 0
      else
        echo -e "${C_Y}لغو شد.${C_RESET}"
      fi
      pause ;;
    0) exit 0 ;;
    *) echo -e "${C_R}گزینه نامعتبر.${C_RESET}"; pause ;;
  esac
}

while true; do show_menu; done
PANEL_BODY

chmod +x "$PANEL_PATH"

if [ -f "$PANEL_PATH" ]; then
    ok "پنل مدیریت ساخته شد (دستور: sudo ${PANEL_CMD})"
else
    warn "ساخت پنل مدیریت ناموفق بود."
fi

# ============================================================
#  تنظیم مجوزهای فایل‌ها
# ============================================================
info "تنظیم مجوزهای فایل‌ها..."

chown -R ${SUDO_USER:-root}:${SUDO_USER:-root} . 2>/dev/null || true
chmod -R 755 . 2>/dev/null || true
chmod +x main.py cli.py 2>/dev/null || true

ok "مجوزهای فایل‌ها تنظیم شد."

# ============================================================
#  پیام نهایی
# ============================================================
echo
echo -e "${C_CYAN}═════════════════════════════════════════════════════════════${C_RESET}"
echo -e "${C_GREEN}✅  نصب کاملاً با موفقیت انجام شد!${C_RESET}"
echo -e "${C_CYAN}═════════════════════════════════════════════════════════════${C_RESET}"
echo ""
echo -e "📌 ${C_MAG}دستور مدیریت ربات:${C_RESET}"
echo "    sudo ${PANEL_CMD}"
echo ""
echo -e "📌 ${C_MAG}دستورات مفید:${C_RESET}"
echo "    وضعیت سرویس:      systemctl status ${SERVICE_NAME}"
echo "    لاگ زنده:         journalctl -u ${SERVICE_NAME} -f"
echo "    ری‌استارت:        systemctl restart ${SERVICE_NAME}"
echo "    توقف:             systemctl stop ${SERVICE_NAME}"
echo "    روشن‌کردن:        systemctl start ${SERVICE_NAME}"
echo ""
echo -e "📌 ${C_MAG}مسیرهای مهم:${C_RESET}"
echo "    دیتابیس:          ${SCRIPT_DIR}/data/bot.sqlite"
echo "    فایل تنظیمات:     ${SCRIPT_DIR}/.env"
echo "    لاگ ربات:         ${SCRIPT_DIR}/logs/bot.log"
echo "    مدل‌های AI:       ${SCRIPT_DIR}/models/"
echo ""
echo -e "${C_CYAN}═════════════════════════════════════════════════════════════${C_RESET}"
echo -e "${C_GREEN}🤖  حالا برو توی تلگرام و به ربات /start بزن.${C_RESET}"
echo -e "${C_CYAN}═════════════════════════════════════════════════════════════${C_RESET}"
echo ""

# ============================================================
#  بررسی نهایی سرویس
# ============================================================
if command -v systemctl >/dev/null 2>&1; then
    if systemctl is-active --quiet "${SERVICE_NAME}" 2>/dev/null; then
        ok "سرویس ${SERVICE_NAME} در حال اجرا است."
    else
        warn "سرویس ${SERVICE_NAME} در حال اجرا نیست."
        info "برای اجرا: sudo systemctl start ${SERVICE_NAME}"
    fi
fi

ok "نصب کامل شد. موفق باشی 🚀"
exit 0